
# Master UI System Merge + Award Management Center

## Scope
Phase 1 — Merge Project B UI assets/components into Project A as reusable primitives.
Phase 2 — Build full Award Management Center (admin CRUD + libraries + rules + previews) as the core of the AMS workspace, using API-ready placeholder data layer (no backend wiring yet).

## Phase 1 — UI Foundation Merge

1. **Import 3D assets** from Project B into `src/assets/` via lovable-assets CDN:
   badge-3d, trophy-3d, medal-3d, passport-3d, badge-laurel, medal-gold, trophy-gold, hero-trophy.
2. **Port reusable components** (strip mock data, parameterize props):
   - `Celebration.tsx` → `src/components/ams/effects/Celebration.tsx` (confetti, coin rain, fireworks, trophy unlock, badge unlock — driven by `useCelebration()` hook + event type prop)
   - `celebrate.ts` util → `src/lib/celebrate.ts`
   - `ChatScreen.tsx` patterns → `src/components/ams/AiAssistantPanel.tsx` (composer + message list, no mock messages)
   - Extract from `screens.tsx`: `AwardCard`, `TrophyShelf`, `BadgeGrid`, `RarityBadge`, `XPRing`, `StreakFlame`, `MilestoneTimeline`, `LeaderboardRow`, `LevelProgress`, `PassportCard`, `RewardChip` → split into `src/components/ams/primitives/`.
3. **Standardize design tokens** — keep current navy/gold theme. Add `--rarity-common/uncommon/rare/epic/legendary/mythic` tokens and rarity badge variants.
4. **Shared UI patterns** added to `src/components/ams/shared/`:
   - `DataTable` (sortable, filterable, bulk-select, row actions)
   - `FilterBar` (category/role/module/status/visibility/rarity/level/xp/date/search)
   - `EmptyState`, `LoadingState`, `ConfirmDialog`, `DetailDrawer`, `FormSheet`
   - `MediaUploader` (3D/Lottie/GIF/sound — accepts file, shows preview)
   - `RuleBuilder` (condition rows for unlock/eligibility)
   - `PreviewStage` (3D/animation/sound preview panel)

## Phase 2 — Award Management Center

New route group `/awards/*` (replaces scattered stub pages where appropriate):

```
/awards                      Award list (table + grid toggle, filters, bulk ops)
/awards/new                  Create form (wizard: basics → media → rules → rewards → visibility → review)
/awards/$id                  Detail page (tabs: Overview, Preview, Rules, Rewards, Usage, Audit, Versions)
/awards/$id/edit             Edit (same wizard, prefilled)
/awards/categories           Category manager (15 categories listed in spec)
/awards/libraries/trophies   Trophy Library
/awards/libraries/badges     Badge Library
/awards/libraries/achievements
/awards/libraries/ranks
/awards/rules/xp             XP Rules
/awards/rules/levels         Level Rules
/awards/rules/rewards        Reward Rules
/awards/rules/streaks        Streak Rules
/awards/rules/milestones     Milestone Rules
/awards/effects              Celebration animations + sound library (coin rain, confetti, fireworks, badge/trophy unlock, XP, reward)
/awards/audit                Audit log of all award actions
```

**Award entity model** (TypeScript types in `src/lib/ams/types.ts`):
- id, name, slug, description, category (15-enum), rarity, priority, status (draft|pending|approved|published|archived|disabled), visibility
- media: { 3dModel, animatedIcon, lottie, gif, sound, themeColor }
- unlockConditions[], eligibilityRules[], supportedModules[], supportedRoles[]
- rewards: { xp, coins, rankImpact, levelImpact, monetaryValue }
- unlockAnimation, celebrationAnimation
- versions[], auditLog[], usageStats

**Data layer** — `src/lib/ams/awards.api.ts` exports typed functions (`listAwards`, `getAward`, `createAward`, `updateAward`, `deleteAward`, `archiveAward`, `restoreAward`, `approveAward`, `rejectAward`, `publishAward`, `unpublishAward`, `cloneAward`, `bulkUpdate`, …). Each returns `Promise<T>` and currently resolves from in-memory empty arrays with TODO markers — wired through TanStack Query so backend swap is a single-file change.

**Actions on each award**: Create, Edit, Delete, Archive, Restore, Preview, Approve, Reject, Publish, Unpublish, Clone, Enable/Disable — exposed in row actions menu + detail page header.

**Bulk operations toolbar**: Create, Edit, Delete, Publish, Archive, Category Change, Role Assignment.

**Detail page tabs**:
- Overview — name, status chips, hero 3D preview, key stats
- Preview — 3D model viewer, animation player, sound player, unlock/celebration simulation buttons (trigger `Celebration` component)
- Rules — unlock conditions, eligibility, modules, roles, visibility (read-only with edit-in-place)
- Rewards — XP, coins, rank/level impact, monetary
- Usage — usage history table + chart
- Audit — audit logs
- Versions — version history with diff/rollback affordance

## Phase 3 — Top-bar nav update
Update `TopBar.tsx`: primary row becomes Command, **Awards** (new mega-section), Leaderboards, Hall of Fame, Analytics, AI, Settings. Legacy stubs (achievements/badges/trophies/xp/levels/ranks/missions/rewards/quests/challenges/claims/notifications/audit) become deep-links under `/awards/*` or remain as thin re-exports pointing into the new structure.

## Out of scope (per user)
- No login/register/auth screens
- No backend wiring this turn (data layer is placeholder, ready for one-file swap)
- No real data — fields render empty states until APIs return data
