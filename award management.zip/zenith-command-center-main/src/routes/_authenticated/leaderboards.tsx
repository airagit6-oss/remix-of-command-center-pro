import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/leaderboards")({
  head: () => ({ meta: [{ title: "Leaderboards — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="leaderboards"
        title="Leaderboards"
        description="Global, country, state, city, territory, role and team"
        sections={["Global", "Country", "State", "City", "Territory", "Role", "Team"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
