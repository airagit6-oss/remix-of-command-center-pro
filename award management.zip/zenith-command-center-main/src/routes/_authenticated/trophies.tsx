import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/trophies")({
  head: () => ({ meta: [{ title: "Trophies — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="trophies"
        title="Trophies"
        description="Bronze, silver, gold, platinum + analytics"
        sections={["Bronze", "Silver", "Gold", "Platinum", "Trophy Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
