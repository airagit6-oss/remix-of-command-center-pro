import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/rewards")({
  head: () => ({ meta: [{ title: "Rewards — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="rewards"
        title="Rewards"
        description="Store, inventory, wallets and analytics"
        sections={["Reward Store", "Reward Inventory", "Reward Wallet", "Reward Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
