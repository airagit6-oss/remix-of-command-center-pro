import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/claims")({
  head: () => ({ meta: [{ title: "Claims — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="claims"
        title="Claims"
        description="Pending, approved, rejected, fulfilled and analytics"
        sections={["Pending", "Approved", "Rejected", "Fulfilled", "Claim Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
