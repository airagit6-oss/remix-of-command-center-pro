import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/ai")({
  head: () => ({ meta: [{ title: "AI Center — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="ai"
        title="AI Center"
        description="Prompts, growth analysis, recommendations, suggestions"
        sections={["AI Prompts", "AI Growth Analysis", "AI Recommendation", "AI Achievement Suggestions", "AI Reward Suggestions"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
