import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/hall-of-fame")({
  head: () => ({ meta: [{ title: "Hall of Fame — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="hall-of-fame"
        title="Hall of Fame"
        description="Champions wall, top 100 and legends board"
        sections={["Hall of Fame", "Champions Wall", "Top 100", "Legends Board"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
