import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/quests")({
  head: () => ({ meta: [{ title: "Quests — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="quests"
        title="Quests"
        description="Multi-step quest lines and chapters"
        sections={["Quest Library", "Quest Chapters", "Quest Rules", "Quest Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
