import { createFileRoute } from "@tanstack/react-router";
import { Gift } from "lucide-react";
import { LibraryShell } from "@/components/ams/shared/LibraryShell";

export const Route = createFileRoute("/_authenticated/awards/rules/rewards")({
  head: () => ({ meta: [{ title: "Reward Rules — AMS" }] }),
  component: () => (
    <LibraryShell
      kicker="Rules" title="Reward rules"
      description="What reward is granted when an award unlocks — coins, monetary value, perks and claim flows."

      helpIcon={<Gift className="h-6 w-6" />}
    />
  ),
});
