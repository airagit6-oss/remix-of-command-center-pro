import { createFileRoute } from "@tanstack/react-router";
import { LibraryPage } from "@/components/ams/shared/LibraryPage";

export const Route = createFileRoute("/_authenticated/awards/libraries/ranks")({
  head: () => ({ meta: [{ title: "Rank Library — AMS" }] }),
  component: () => <LibraryPage type="rank" kicker="Library" title="Ranks" description="Persistent tiers. Rank-up celebrations are full-screen by default." />,
});
