import { createFileRoute } from "@tanstack/react-router";
import { LibraryPage } from "@/components/ams/shared/LibraryPage";

export const Route = createFileRoute("/_authenticated/awards/libraries/achievements")({
  head: () => ({ meta: [{ title: "Achievement Library — AMS" }] }),
  component: () => <LibraryPage type="achievement" kicker="Library" title="Achievements" description="In-product milestones that trigger XP, coins and celebrations." />,
});
