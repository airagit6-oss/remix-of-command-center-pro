import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpCircle } from "lucide-react";
import { LibraryShell } from "@/components/ams/shared/LibraryShell";

export const Route = createFileRoute("/_authenticated/awards/rules/levels")({
  head: () => ({ meta: [{ title: "Level Rules — AMS" }] }),
  component: () => (
    <LibraryShell
      kicker="Rules" title="Level rules"
      description="XP thresholds, level perks, level-up rewards and level-bound visibility."

      helpIcon={<ArrowUpCircle className="h-6 w-6" />}
    />
  ),
});
