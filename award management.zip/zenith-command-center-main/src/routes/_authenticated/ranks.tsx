import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/ranks")({
  head: () => ({ meta: [{ title: "Ranks — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="ranks"
        title="Ranks"
        description="Rank matrix, benefits, progression & analytics"
        sections={["Rank Matrix", "Rank Benefits", "Rank Progression", "Rank Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
