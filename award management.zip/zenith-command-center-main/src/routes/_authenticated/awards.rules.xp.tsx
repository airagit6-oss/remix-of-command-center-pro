import { createFileRoute } from "@tanstack/react-router";
import { Zap } from "lucide-react";
import { LibraryShell } from "@/components/ams/shared/LibraryShell";

export const Route = createFileRoute("/_authenticated/awards/rules/xp")({
  head: () => ({ meta: [{ title: "XP Rules — AMS" }] }),
  component: () => (
    <LibraryShell
      kicker="Rules" title="XP rules"
      description="Define how XP is granted across modules — base actions, multipliers, decay and caps."

      helpIcon={<Zap className="h-6 w-6" />}
    />
  ),
});
