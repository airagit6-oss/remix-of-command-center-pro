import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { CelebrationProvider } from "@/components/ams/effects/Celebration";
import { Toaster } from "@/components/ui/sonner";

// Auth is handled by the parent Software Vala application.
// This module assumes the user is already authenticated upstream.
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  return (
    <CelebrationProvider>
      <AppShell>
        <Outlet />
      </AppShell>
      <Toaster richColors position="bottom-right" />
    </CelebrationProvider>
  );
}
