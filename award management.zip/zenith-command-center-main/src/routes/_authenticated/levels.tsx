import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/levels")({
  head: () => ({ meta: [{ title: "Levels — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="levels"
        title="Levels"
        description="Level matrix, rewards, progression & analytics"
        sections={["Level Matrix", "Level Rewards", "Level Progression", "Level Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
