import { createFileRoute } from "@tanstack/react-router";
import { LibraryPage } from "@/components/ams/shared/LibraryPage";

export const Route = createFileRoute("/_authenticated/awards/libraries/badges")({
  head: () => ({ meta: [{ title: "Badge Library — AMS" }] }),
  component: () => <LibraryPage type="badge" kicker="Library" title="Badges" description="Identity markers awarded for skills, milestones and contributions." />,
});
