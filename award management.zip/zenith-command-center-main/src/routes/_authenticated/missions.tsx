import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/missions")({
  head: () => ({ meta: [{ title: "Missions — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="missions"
        title="Missions"
        description="Daily, weekly, monthly and seasonal missions"
        sections={["Daily", "Weekly", "Monthly", "Seasonal", "Mission Rules", "Mission Analytics"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
