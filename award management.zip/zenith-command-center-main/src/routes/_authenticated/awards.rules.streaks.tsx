import { createFileRoute } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { LibraryShell } from "@/components/ams/shared/LibraryShell";

export const Route = createFileRoute("/_authenticated/awards/rules/streaks")({
  head: () => ({ meta: [{ title: "Streak Rules — AMS" }] }),
  component: () => (
    <LibraryShell
      kicker="Rules" title="Streak rules"
      description="Daily/weekly streak windows, freeze rules, reset behavior and streak bonuses."

      helpIcon={<Sparkles className="h-6 w-6" />}
    />
  ),
});
