import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/achievements")({
  head: () => ({ meta: [{ title: "Achievements — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="achievements"
        title="Achievements"
        description="Achievement library, categories, rules, conditions, analytics & audit"
        sections={["Achievement Library", "Achievement Categories", "Achievement Rules", "Achievement Conditions", "Achievement Analytics", "Achievement Audit"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
