import { createFileRoute } from "@tanstack/react-router";
import { LibraryPage } from "@/components/ams/shared/LibraryPage";

export const Route = createFileRoute("/_authenticated/awards/libraries/trophies")({
  head: () => ({ meta: [{ title: "Trophy Library — AMS" }] }),
  component: () => <LibraryPage type="trophy" kicker="Library" title="Trophies" description="Top-tier awards. Full-screen unlocks, premium 3D models, gold gradients." />,
});
