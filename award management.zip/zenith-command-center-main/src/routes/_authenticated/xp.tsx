import { createFileRoute } from "@tanstack/react-router";
import { PageStub, ToolbarStub } from "@/components/PageStub";

export const Route = createFileRoute("/_authenticated/xp")({
  head: () => ({ meta: [{ title: "XP — AMS" }] }),
  component: Page,
});

function Page() {
  return (
    <div className="space-y-6">
      <PageStub
        kicker="xp"
        title="XP"
        description="XP rules, sources, transactions, analytics & audit"
        sections={["XP Rules", "XP Sources", "XP Transactions", "XP Analytics", "XP Audit"]}
      />
      <div className="max-w-[1400px] mx-auto">
        <ToolbarStub />
      </div>
    </div>
  );
}
