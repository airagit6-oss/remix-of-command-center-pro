import { type ReactNode } from "react";
import { TopBar } from "./TopBar";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <TopBar />
      <main className="flex-1 px-6 py-6 max-w-[1600px] w-full mx-auto">{children}</main>
    </div>
  );
}
