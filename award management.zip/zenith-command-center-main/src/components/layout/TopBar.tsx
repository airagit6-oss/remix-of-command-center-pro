import { Link, useRouterState } from "@tanstack/react-router";
import {
  Bell, Search, Sparkles, Trophy, Zap, ChevronDown, User2,
  LayoutDashboard, Shield, Award, ArrowUpCircle, Crown, Target,
  Gift, BarChart3, LineChart, ScrollText, Star,
  Settings, MoreHorizontal, Layers, FolderTree, Wand2, LifeBuoy,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

type NavItem = { to: string; label: string; icon: React.ComponentType<{ className?: string }> };

const PRIMARY_NAV: NavItem[] = [
  { to: "/", label: "Command", icon: LayoutDashboard },
  { to: "/awards", label: "Awards", icon: Trophy },
  { to: "/ams", label: "AMS Tickets", icon: LifeBuoy },
  { to: "/awards/categories", label: "Categories", icon: FolderTree },
  { to: "/awards/effects", label: "Effects", icon: Wand2 },
  { to: "/leaderboards", label: "Leaderboards", icon: BarChart3 },
  { to: "/hall-of-fame", label: "Hall of Fame", icon: Star },
  { to: "/analytics", label: "Analytics", icon: LineChart },
  { to: "/ai", label: "AI Center", icon: Sparkles },
];

const LIBRARIES_NAV: NavItem[] = [
  { to: "/awards/libraries/trophies",     label: "Trophies",     icon: Trophy },
  { to: "/awards/libraries/badges",       label: "Badges",       icon: Shield },
  { to: "/awards/libraries/achievements", label: "Achievements", icon: Award },
  { to: "/awards/libraries/ranks",        label: "Ranks",        icon: Crown },
];

const RULES_NAV: NavItem[] = [
  { to: "/awards/rules/xp",         label: "XP rules",         icon: Zap },
  { to: "/awards/rules/levels",     label: "Level rules",      icon: ArrowUpCircle },
  { to: "/awards/rules/rewards",    label: "Reward rules",     icon: Gift },
  { to: "/awards/rules/streaks",    label: "Streak rules",     icon: Sparkles },
  { to: "/awards/rules/milestones", label: "Milestone rules",  icon: Crown },
];

const MORE_NAV: NavItem[] = [
  { to: "/awards/audit",   label: "Audit log",     icon: ScrollText },
  { to: "/missions",       label: "Missions",      icon: Target },
  { to: "/quests",         label: "Quests",        icon: Layers },
  { to: "/challenges",     label: "Challenges",    icon: Target },
  { to: "/claims",         label: "Claims",        icon: Gift },
  { to: "/notifications",  label: "Notifications", icon: Bell },
  { to: "/settings",       label: "Settings",      icon: Settings },
];

export function TopBar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur-xl">
      {/* Row 1 — brand + search + actions */}
      <div className="h-14 flex items-center gap-3 px-5">
        <Link to="/" className="flex items-center gap-2.5 shrink-0">
          <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-trophy to-legendary flex items-center justify-center shadow-[0_0_20px_-4px_oklch(0.82_0.17_85/60%)]">
            <Trophy className="h-4.5 w-4.5 text-background" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-bold tracking-tight text-gradient-trophy">AMS</div>
            <div className="text-[9px] text-muted-foreground uppercase tracking-[0.15em]">Command Center</div>
          </div>
        </Link>

        <div className="h-7 w-px bg-border mx-1" />

        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search achievements, users, rewards…"
            className="pl-9 h-9 bg-muted/30 border-border/60"
          />
          <kbd className="absolute right-3 top-1/2 -translate-y-1/2 hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border border-border bg-muted/60 px-1.5 font-mono text-[10px] text-muted-foreground">
            ⌘K
          </kbd>
        </div>

        <div className="flex items-center gap-1 ml-auto">
          <Button variant="ghost" size="icon" title="Achievement alerts" className="relative">
            <Trophy className="h-4 w-4 text-trophy" />
            <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-trophy glow-trophy" />
          </Button>
          <Button variant="ghost" size="icon" title="Notifications" className="relative">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" title="AI Assistant">
            <Sparkles className="h-4 w-4 text-trophy" />
          </Button>
          <Button variant="ghost" size="icon" title="Quick actions">
            <Zap className="h-4 w-4 text-xp" />
          </Button>

          <div className="h-6 w-px bg-border mx-1" />

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-9 gap-2 px-2">
                <div className="h-7 w-7 rounded-full bg-gradient-to-br from-trophy to-legendary flex items-center justify-center text-xs font-semibold text-background">
                  A
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="text-xs text-muted-foreground">Admin</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem><User2 className="h-4 w-4 mr-2" /> Profile</DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/settings"><Settings className="h-4 w-4 mr-2" /> Settings</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Row 2 — horizontal nav */}
      <nav className="h-11 flex items-center gap-1 px-3 overflow-x-auto border-t border-border/40">
        {PRIMARY_NAV.map((item) => {
          const active = pathname === item.to;
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "relative flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors",
                active
                  ? "text-trophy bg-trophy/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {item.label}
              {active && <span className="absolute -bottom-[10px] left-2 right-2 h-[2px] rounded-full bg-trophy glow-trophy" />}
            </Link>
          );
        })}

        <NavDropdown label="Libraries" icon={Layers} items={LIBRARIES_NAV} pathname={pathname} />
        <NavDropdown label="Rules" icon={Wand2} items={RULES_NAV} pathname={pathname} />
        <NavDropdown label="More" icon={MoreHorizontal} items={MORE_NAV} pathname={pathname} />
      </nav>
    </header>
  );
}

function NavDropdown({
  label, icon: Icon, items, pathname,
}: {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  items: NavItem[];
  pathname: string;
}) {
  const active = items.some((n) => pathname === n.to || pathname.startsWith(n.to + "/"));
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors",
            active
              ? "text-trophy bg-trophy/10"
              : "text-muted-foreground hover:text-foreground hover:bg-muted/40",
          )}
        >
          <Icon className="h-3.5 w-3.5" />
          {label}
          <ChevronDown className="h-3 w-3" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        {items.map((item) => {
          const ItemIcon = item.icon;
          return (
            <DropdownMenuItem key={item.to} asChild>
              <Link to={item.to}>
                <ItemIcon className="h-4 w-4 mr-2" /> {item.label}
              </Link>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
