import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MarketplaceTopBar, type SectionId } from "@/components/marketplace/TopBar";
import { DashboardSection } from "@/components/marketplace/sections/DashboardSection";
import {
  HeroBannerSection,
  CategoriesSection,
  WallsSection,
  PlacementSection,
  CardsSection,
  ActionsSection,
  OffersSection,
  PopupsSection,
  PartnersSection,
  TrustSection,
  ReviewsSection,
  FaqSection,
  ContactSection,
  SearchSection,
  AiSection,
  SeoSection,
  StickySection,
  AnalyticsSection,
  SettingsSection,
  StorefrontTopBarSection,
  FooterSection,
  FiltersSection,
  UpcomingSection,
  NotificationsSection,
  LayoutOrderSection,
  DeploymentSection,
  IntegritySection,
  MicroFeaturesSection,
  ToolkitSection,
  TopBarManagerSection,
  HomepageRowsSection,
  CardManagerSection,
} from "@/components/marketplace/sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Marketplace Homepage Manager — Software Vala Boss Panel" },
      {
        name: "description",
        content:
          "Control the entire Software Vala marketplace homepage: banners, walls, categories, offers, partners, SEO and analytics from one console.",
      },
      { property: "og:title", content: "Marketplace Homepage Manager" },
      {
        property: "og:description",
        content:
          "Operator console for products, walls, banners, offers, partners and revenue.",
      },
    ],
  }),
  component: MarketplaceManager,
});

function MarketplaceManager() {
  const [section, setSection] = useState<SectionId>("dashboard");

  return (
    <div className="min-h-screen bg-background text-foreground">
      <MarketplaceTopBar active={section} onChange={setSection} />
      <main>{renderSection(section)}</main>
    </div>
  );
}

function renderSection(id: SectionId) {
  switch (id) {
    case "dashboard": return <DashboardSection />;
    case "topbar-manager": return <TopBarManagerSection />;
    case "homepage-rows": return <HomepageRowsSection />;
    case "card-manager": return <CardManagerSection />;
    case "toolkit": return <ToolkitSection />;
    case "storefront-topbar": return <StorefrontTopBarSection />;
    case "hero": return <HeroBannerSection />;
    case "categories": return <CategoriesSection />;
    case "walls": return <WallsSection />;
    case "layout-order": return <LayoutOrderSection />;
    case "placement": return <PlacementSection />;
    case "cards": return <CardsSection />;
    case "actions": return <ActionsSection />;
    case "filters": return <FiltersSection />;
    case "offers": return <OffersSection />;
    case "popups": return <PopupsSection />;
    case "upcoming": return <UpcomingSection />;
    case "partners": return <PartnersSection />;
    case "trust": return <TrustSection />;
    case "reviews": return <ReviewsSection />;
    case "faq": return <FaqSection />;
    case "contact": return <ContactSection />;
    case "footer": return <FooterSection />;
    case "search": return <SearchSection />;
    case "ai": return <AiSection />;
    case "seo": return <SeoSection />;
    case "sticky": return <StickySection />;
    case "notifications": return <NotificationsSection />;
    case "analytics": return <AnalyticsSection />;
    case "deployment": return <DeploymentSection />;
    case "micro": return <MicroFeaturesSection />;
    case "integrity": return <IntegritySection />;

    case "settings": return <SettingsSection />;
  }
}
