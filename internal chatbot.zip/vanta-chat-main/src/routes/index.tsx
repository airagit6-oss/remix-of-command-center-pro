import { createFileRoute } from "@tanstack/react-router";
import ChatApp from "@/components/chat/ChatApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Software Vala — Enterprise Chat" },
      { name: "description", content: "A premium enterprise internal communication platform with a world-class chat experience." },
      { property: "og:title", content: "Software Vala — Enterprise Chat" },
      { property: "og:description", content: "A premium enterprise internal communication platform with a world-class chat experience." },
    ],
  }),
  component: ChatApp,
});
