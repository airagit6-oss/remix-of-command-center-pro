import {
  LayoutDashboard, Brain, MessageCircle, Bell, Search, Calendar,
  Activity, CheckSquare, FolderOpen, User, Settings, ShieldCheck,
  LifeBuoy, Ticket, ScrollText, FileBarChart, Sparkles, Languages,
  Calculator, Coins, Inbox, Megaphone, BookOpen, Keyboard, Star, Clock,
  type LucideIcon,
} from "lucide-react";

export type GlobalModule = { key: string; label: string; icon: LucideIcon; group: "core" | "comms" | "tools" | "account" };

export const GLOBAL_MODULES: GlobalModule[] = [
  { key: "g:ams",            label: "AMS (AI System)",   icon: Brain,           group: "core" },
  { key: "g:chat",           label: "Internal Chat",     icon: MessageCircle,   group: "comms" },
  { key: "g:notifications",  label: "Notifications",     icon: Bell,            group: "comms" },
  { key: "g:inbox",          label: "Inbox",             icon: Inbox,           group: "comms" },
  { key: "g:announcements",  label: "Announcements",     icon: Megaphone,       group: "comms" },
  { key: "g:search",         label: "Global Search",     icon: Search,          group: "tools" },
  { key: "g:calendar",       label: "Calendar",          icon: Calendar,        group: "tools" },
  { key: "g:activity",       label: "Activity Timeline", icon: Activity,        group: "tools" },
  { key: "g:tasks",          label: "Tasks",             icon: CheckSquare,     group: "tools" },
  { key: "g:files",          label: "Files",             icon: FolderOpen,      group: "tools" },
  { key: "g:reports",        label: "Reports",           icon: FileBarChart,    group: "tools" },
  { key: "g:audit",          label: "Audit Logs",        icon: ScrollText,      group: "tools" },
  { key: "g:ai-assistant",   label: "AI Assistant",      icon: Sparkles,        group: "tools" },
  { key: "g:translation",    label: "Translation",       icon: Languages,       group: "tools" },
  { key: "g:calculator",     label: "Calculator",        icon: Calculator,      group: "tools" },
  { key: "g:currency",       label: "Currency Converter",icon: Coins,           group: "tools" },
  { key: "g:knowledge",      label: "Knowledge Base",    icon: BookOpen,        group: "tools" },
  { key: "g:shortcuts",      label: "Shortcuts",         icon: Keyboard,        group: "tools" },
  { key: "g:favorites",      label: "Favorites",         icon: Star,            group: "tools" },
  { key: "g:recent",         label: "Recent Activity",   icon: Clock,           group: "tools" },
  { key: "g:profile",        label: "Profile",           icon: User,            group: "account" },
  { key: "g:settings",       label: "Settings",          icon: Settings,        group: "account" },
  { key: "g:security",       label: "Security",          icon: ShieldCheck,     group: "account" },
  { key: "g:help",           label: "Help Center",       icon: LifeBuoy,        group: "account" },
  { key: "g:support",        label: "Support Ticket",    icon: Ticket,          group: "account" },
];

export const GLOBAL_MODULE_KEYS = new Set(GLOBAL_MODULES.map(m => m.key));
