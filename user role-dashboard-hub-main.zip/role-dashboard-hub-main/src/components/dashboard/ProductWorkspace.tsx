import { useMemo, useState, useEffect, useRef } from "react";
import {
  ArrowLeft, Plus, Search, Download, Upload, Trash2, Copy, Archive, ArchiveRestore,
  Check, X, Eye, Pencil, LayoutGrid, List as ListIcon, Table as TableIcon,
  ChevronLeft, ChevronRight, FileJson, Package, Star, Tag, Image as ImageIcon,
  Video, FileText, Link as LinkIcon, DollarSign, ShieldCheck, History, BarChart3,
  Sparkles, Globe, Box, Layers, Inbox,
} from "lucide-react";
import { toast } from "sonner";
import type { RoleConfig } from "@/lib/roles";
import { useCrud, exportJson, downloadFile, type CrudRecord, type RecordStatus } from "@/lib/crud-store";

type View = "table" | "grid" | "list";
type Mode = { kind: "list" } | { kind: "detail"; id: string } | { kind: "add" } | { kind: "edit"; id: string };
type Tab = "overview" | "media" | "pricing" | "inventory" | "seo" | "support" | "versions" | "analytics" | "rules";

const STATUS_OPTIONS: RecordStatus[] = ["active", "draft", "pending", "approved", "rejected", "archived"];
const PRODUCT_TYPES = ["SaaS", "Digital", "Offline", "AI", "Service", "Subscription"] as const;
const VISIBILITIES = ["public", "private", "unlisted"] as const;
const CURRENCIES = ["USD", "EUR", "GBP", "INR", "AUD"] as const;
const CATEGORIES = ["Productivity", "Marketing", "Developer Tools", "AI & ML", "Design", "Analytics", "Security", "Finance"];

const STATUS_TONE: Record<RecordStatus, string> = {
  active:   "bg-success/15 text-success",
  pending:  "bg-warning/15 text-warning",
  approved: "bg-brand/15 text-brand",
  rejected: "bg-danger/15 text-danger",
  draft:    "bg-surface-2 text-muted-foreground",
  archived: "bg-surface-2 text-muted-foreground/70 line-through",
};

function Pill({ s }: { s: RecordStatus }) {
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${STATUS_TONE[s]}`}>{s}</span>;
}
function money(n: number, c = "USD") {
  return n.toLocaleString(undefined, { style: "currency", currency: c, maximumFractionDigits: 0 });
}
function fmtDate(s: string) {
  try { return new Date(s).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }); }
  catch { return s; }
}
function str(v: string | number | undefined, fb = ""): string {
  return v === undefined || v === null ? fb : String(v);
}
function num(v: string | number | undefined, fb = 0): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fb;
}

export function ProductWorkspace({ role, moduleKey, onBack }: { role: RoleConfig; moduleKey: string; onBack: () => void }) {
  const mod = role.modules.find((m) => m.key === moduleKey) ?? { key: moduleKey, label: "Products", icon: Package };
  const crud = useCrud(role.key, moduleKey);

  // ---- Seed product-specific extras for any record missing them (idempotent) ----
  useEffect(() => {
    crud.records.forEach((r, i) => {
      if (!r.extra.sku) {
        crud.update(r.id, {
          extra: {
            sku: `SKU-${r.id.slice(-6).toUpperCase()}`,
            code: `PRD-${String(i + 1).padStart(4, "0")}`,
            barcode: `8901${Math.floor(100000 + Math.random() * 899999)}`,
            type: PRODUCT_TYPES[i % PRODUCT_TYPES.length],
            visibility: "public",
            currency: "USD",
            price: r.amount || 99,
            mrp: (r.amount || 99) + 50,
            discountPct: 10,
            lifetimePrice: (r.amount || 99) * 8,
            taxPct: 18,
            stock: 100 + (i * 17) % 500,
            lowStock: 10,
            brand: r.category || "House Brand",
            subCategory: CATEGORIES[(i + 1) % CATEGORIES.length],
            featured: i % 3 === 0 ? 1 : 0,
            trending: i % 4 === 0 ? 1 : 0,
            bestseller: i % 5 === 0 ? 1 : 0,
            aiReady: /AI/i.test(String(PRODUCT_TYPES[i % PRODUCT_TYPES.length])) ? 1 : 0,
            version: "1.0.0",
            rating: Number((3.8 + (i % 10) / 10).toFixed(1)),
            reviews: 5 + (i * 13) % 200,
            views: 100 + (i * 47) % 5000,
            sales: 10 + (i * 7) % 500,
            demoUrl: "https://example.com/demo",
            downloadUrl: "",
            seoTitle: r.name,
            seoDesc: `Buy ${r.name} — production-ready ${PRODUCT_TYPES[i % PRODUCT_TYPES.length]} product.`,
            seoKeywords: `${r.name.toLowerCase()}, ${PRODUCT_TYPES[i % PRODUCT_TYPES.length].toLowerCase()}, software`,
            releaseNotes: "Initial release.",
            compatibility: "Web, Windows, macOS, Linux",
            dependencies: "None",
            faqs: "Q: Is there a refund? A: 14-day money-back guarantee.",
          },
        });
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [mode, setMode] = useState<Mode>({ kind: "list" });
  const [tab, setTab] = useState<Tab>("overview");
  const [view, setView] = useState<View>("table");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<RecordStatus | "all">("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [sort, setSort] = useState<"date_desc" | "price_desc" | "name_asc" | "sales_desc" | "rating_desc">("date_desc");
  const [page, setPage] = useState(1);
  const pageSize = 8;
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setMode({ kind: "list" }); setPage(1); setSelected(new Set()); setQuery(""); }, [moduleKey, role.key]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = crud.records.filter((r) => {
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (typeFilter !== "all" && str(r.extra.type) !== typeFilter) return false;
      if (!q) return true;
      return r.name.toLowerCase().includes(q)
        || str(r.extra.sku).toLowerCase().includes(q)
        || str(r.extra.code).toLowerCase().includes(q)
        || r.category.toLowerCase().includes(q)
        || r.tags.some((t) => t.toLowerCase().includes(q));
    });
    list = [...list].sort((a, b) => {
      switch (sort) {
        case "price_desc":  return num(b.extra.price) - num(a.extra.price);
        case "name_asc":    return a.name.localeCompare(b.name);
        case "sales_desc":  return num(b.extra.sales) - num(a.extra.sales);
        case "rating_desc": return num(b.extra.rating) - num(a.extra.rating);
        default:            return b.date.localeCompare(a.date);
      }
    });
    return list;
  }, [crud.records, query, statusFilter, typeFilter, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageItems = filtered.slice((page - 1) * pageSize, page * pageSize);

  const current = mode.kind === "detail" || mode.kind === "edit" ? crud.records.find((r) => r.id === mode.id) : null;

  // ---- Stats ----
  const kpis = useMemo(() => {
    const all = crud.records;
    const totalRevenue = all.reduce((s, r) => s + num(r.extra.price) * num(r.extra.sales), 0);
    const lowStock = all.filter((r) => num(r.extra.stock) <= num(r.extra.lowStock)).length;
    const featured = all.filter((r) => num(r.extra.featured) === 1).length;
    return { total: all.length, revenue: totalRevenue, lowStock, featured };
  }, [crud.records]);

  // ---- Actions ----
  function toggle(id: string) {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  }
  function toggleAll() {
    if (selected.size === pageItems.length) setSelected(new Set());
    else setSelected(new Set(pageItems.map((r) => r.id)));
  }
  function bulkStatus(s: RecordStatus) {
    if (selected.size === 0) return toast.error("Select products first");
    crud.bulkSetStatus([...selected], s);
    toast.success(`${selected.size} product(s) → ${s}`);
    setSelected(new Set());
  }
  function bulkDelete() {
    if (selected.size === 0) return toast.error("Select products first");
    if (!confirm(`Delete ${selected.size} product(s)? This cannot be undone.`)) return;
    crud.bulkRemove([...selected]);
    toast.success(`${selected.size} product(s) deleted`);
    setSelected(new Set());
  }
  function doImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const n = crud.importJson(String(reader.result || "[]"));
      n > 0 ? toast.success(`Imported ${n} product(s)`) : toast.error("Import failed");
    };
    reader.readAsText(file);
  }

  // ============ DETAIL VIEW ============
  if ((mode.kind === "detail" || mode.kind === "edit") && current) {
    return (
      <ProductDetail
        role={role}
        record={current}
        editing={mode.kind === "edit"}
        onEdit={() => setMode({ kind: "edit", id: current.id })}
        onCancel={() => setMode({ kind: "detail", id: current.id })}
        onSave={(patch) => { crud.update(current.id, patch); toast.success("Product saved"); setMode({ kind: "detail", id: current.id }); }}
        onBack={() => setMode({ kind: "list" })}
        onDuplicate={() => { const c = crud.duplicate(current.id); if (c) { toast.success("Duplicated"); setMode({ kind: "detail", id: c.id }); } }}
        onDelete={() => { if (confirm("Delete this product?")) { crud.remove(current.id); toast.success("Deleted"); setMode({ kind: "list" }); } }}
        onStatus={(s) => { crud.setStatus(current.id, s); toast.success(`Status → ${s}`); }}
        tab={tab}
        onTab={setTab}
      />
    );
  }

  // ============ ADD VIEW ============
  if (mode.kind === "add") {
    return (
      <ProductDetail
        role={role}
        editing
        creating
        record={emptyProduct()}
        onBack={() => setMode({ kind: "list" })}
        onCancel={() => setMode({ kind: "list" })}
        onSave={(patch) => {
          const rec = crud.create({ ...patch, status: patch.status || "draft" });
          toast.success("Product created");
          setMode({ kind: "detail", id: rec.id });
        }}
        tab={tab}
        onTab={setTab}
      />
    );
  }

  // ============ LIST VIEW ============
  return (
    <div className="min-h-[60vh] space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <button onClick={onBack} className="inline-flex items-center gap-1 hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> Dashboard
        </button>
        <span>/</span>
        <span className="text-foreground">{mod.label}</span>
      </div>

      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Product Catalog</h1>
          <p className="text-sm text-muted-foreground">Manage every product — pricing, inventory, SEO, versions and analytics.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => importRef.current?.click()} className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs hover:bg-surface-2 inline-flex items-center gap-1.5">
            <Upload className="h-3.5 w-3.5" /> Import
          </button>
          <input ref={importRef} type="file" accept="application/json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) doImport(f); e.target.value = ""; }} />
          <button onClick={() => downloadFile(`${role.key}-${moduleKey}.json`, exportJson(crud.records))} className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs hover:bg-surface-2 inline-flex items-center gap-1.5">
            <Download className="h-3.5 w-3.5" /> Export
          </button>
          <button onClick={() => { setMode({ kind: "add" }); setTab("overview"); }} className="rounded-md bg-brand px-3 py-1.5 text-xs font-medium text-brand-foreground hover:bg-brand/90 inline-flex items-center gap-1.5">
            <Plus className="h-3.5 w-3.5" /> Add Product
          </button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Kpi icon={Package} label="Total Products" value={kpis.total.toLocaleString()} />
        <Kpi icon={DollarSign} label="Lifetime Revenue" value={money(kpis.revenue)} />
        <Kpi icon={Box} label="Low Stock" value={kpis.lowStock.toLocaleString()} tone={kpis.lowStock > 0 ? "warn" : "ok"} />
        <Kpi icon={Star} label="Featured" value={kpis.featured.toLocaleString()} />
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-surface p-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }}
            placeholder="Search name, SKU, code, tags…"
            className="w-full rounded-md border border-border bg-surface-2 pl-7 pr-2 py-1.5 text-xs outline-none focus:border-brand" />
        </div>
        <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value as RecordStatus | "all"); setPage(1); }}
          className="rounded-md border border-border bg-surface-2 px-2 py-1.5 text-xs">
          <option value="all">All status</option>
          {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setPage(1); }}
          className="rounded-md border border-border bg-surface-2 px-2 py-1.5 text-xs">
          <option value="all">All types</option>
          {PRODUCT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)}
          className="rounded-md border border-border bg-surface-2 px-2 py-1.5 text-xs">
          <option value="date_desc">Newest</option>
          <option value="name_asc">Name A–Z</option>
          <option value="price_desc">Price ↓</option>
          <option value="sales_desc">Sales ↓</option>
          <option value="rating_desc">Rating ↓</option>
        </select>
        <div className="ml-auto flex items-center gap-1 rounded-md border border-border bg-surface-2 p-0.5">
          {([["table", TableIcon], ["grid", LayoutGrid], ["list", ListIcon]] as const).map(([v, I]) => (
            <button key={v} onClick={() => setView(v)} className={`rounded p-1.5 ${view === v ? "bg-surface text-foreground" : "text-muted-foreground hover:text-foreground"}`} aria-label={v}>
              <I className="h-3.5 w-3.5" />
            </button>
          ))}
        </div>
      </div>

      {/* Bulk bar */}
      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-brand/40 bg-brand/5 px-3 py-2 text-xs">
          <span className="font-medium">{selected.size} selected</span>
          <button onClick={() => bulkStatus("approved")} className="rounded border border-border bg-surface px-2 py-1 hover:bg-surface-2 inline-flex items-center gap-1"><Check className="h-3 w-3" /> Approve</button>
          <button onClick={() => bulkStatus("rejected")} className="rounded border border-border bg-surface px-2 py-1 hover:bg-surface-2 inline-flex items-center gap-1"><X className="h-3 w-3" /> Reject</button>
          <button onClick={() => bulkStatus("archived")} className="rounded border border-border bg-surface px-2 py-1 hover:bg-surface-2 inline-flex items-center gap-1"><Archive className="h-3 w-3" /> Archive</button>
          <button onClick={() => bulkStatus("active")} className="rounded border border-border bg-surface px-2 py-1 hover:bg-surface-2 inline-flex items-center gap-1"><ArchiveRestore className="h-3 w-3" /> Restore</button>
          <button onClick={bulkDelete} className="rounded border border-danger/40 bg-danger/10 text-danger px-2 py-1 hover:bg-danger/20 inline-flex items-center gap-1"><Trash2 className="h-3 w-3" /> Delete</button>
          <button onClick={() => setSelected(new Set())} className="ml-auto text-muted-foreground hover:text-foreground">Clear</button>
        </div>
      )}

      {/* Empty / Content */}
      {filtered.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border bg-surface p-10 text-center">
          <Package className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
          <h3 className="text-sm font-medium">No products match</h3>
          <p className="mt-1 text-xs text-muted-foreground">Try a different search, clear filters, or add your first product.</p>
          <button onClick={() => setMode({ kind: "add" })} className="mt-3 rounded-md bg-brand px-3 py-1.5 text-xs font-medium text-brand-foreground inline-flex items-center gap-1.5">
            <Plus className="h-3.5 w-3.5" /> Add Product
          </button>
        </div>
      ) : view === "table" ? (
        <div className="overflow-x-auto rounded-lg border border-border bg-surface">
          <table className="w-full text-xs">
            <thead className="bg-surface-2 text-muted-foreground">
              <tr>
                <th className="p-2 text-left"><input type="checkbox" checked={selected.size === pageItems.length && pageItems.length > 0} onChange={toggleAll} /></th>
                <th className="p-2 text-left">Product</th>
                <th className="p-2 text-left">SKU</th>
                <th className="p-2 text-left">Type</th>
                <th className="p-2 text-right">Price</th>
                <th className="p-2 text-right">Stock</th>
                <th className="p-2 text-right">Sales</th>
                <th className="p-2 text-right">Rating</th>
                <th className="p-2 text-left">Status</th>
                <th className="p-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageItems.map((r) => (
                <tr key={r.id} className="border-t border-border hover:bg-surface-2">
                  <td className="p-2"><input type="checkbox" checked={selected.has(r.id)} onChange={() => toggle(r.id)} /></td>
                  <td className="p-2">
                    <button onClick={() => { setMode({ kind: "detail", id: r.id }); setTab("overview"); }} className="text-left hover:text-brand">
                      <div className="font-medium">{r.name}</div>
                      <div className="text-[10px] text-muted-foreground">{r.category}</div>
                    </button>
                  </td>
                  <td className="p-2 font-mono text-[10px]">{str(r.extra.sku)}</td>
                  <td className="p-2">{str(r.extra.type)}</td>
                  <td className="p-2 text-right">{money(num(r.extra.price), str(r.extra.currency, "USD"))}</td>
                  <td className={`p-2 text-right ${num(r.extra.stock) <= num(r.extra.lowStock) ? "text-warning" : ""}`}>{num(r.extra.stock)}</td>
                  <td className="p-2 text-right">{num(r.extra.sales)}</td>
                  <td className="p-2 text-right">{num(r.extra.rating).toFixed(1)} ★</td>
                  <td className="p-2"><Pill s={r.status} /></td>
                  <td className="p-2">
                    <div className="flex justify-end gap-1">
                      <IconBtn onClick={() => { setMode({ kind: "detail", id: r.id }); setTab("overview"); }} title="View"><Eye className="h-3.5 w-3.5" /></IconBtn>
                      <IconBtn onClick={() => { setMode({ kind: "edit", id: r.id }); setTab("overview"); }} title="Edit"><Pencil className="h-3.5 w-3.5" /></IconBtn>
                      <IconBtn onClick={() => { const c = crud.duplicate(r.id); if (c) toast.success("Duplicated"); }} title="Duplicate"><Copy className="h-3.5 w-3.5" /></IconBtn>
                      <IconBtn onClick={() => { if (confirm("Delete this product?")) { crud.remove(r.id); toast.success("Deleted"); } }} title="Delete"><Trash2 className="h-3.5 w-3.5" /></IconBtn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : view === "grid" ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {pageItems.map((r) => (
            <button key={r.id} onClick={() => { setMode({ kind: "detail", id: r.id }); setTab("overview"); }}
              className="group rounded-lg border border-border bg-surface p-3 text-left hover:border-brand/40">
              <div className="mb-2 flex aspect-video items-center justify-center rounded-md bg-gradient-to-br from-brand/20 to-surface-2">
                <Package className="h-10 w-10 text-brand/60" />
              </div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-sm font-medium group-hover:text-brand">{r.name}</div>
                  <div className="text-[10px] text-muted-foreground">{str(r.extra.type)} · {r.category}</div>
                </div>
                <Pill s={r.status} />
              </div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="font-semibold">{money(num(r.extra.price), str(r.extra.currency, "USD"))}</span>
                <span className="text-muted-foreground">{num(r.extra.rating).toFixed(1)}★ · {num(r.extra.sales)} sold</span>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="divide-y divide-border rounded-lg border border-border bg-surface">
          {pageItems.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-3 p-3 hover:bg-surface-2">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-surface-2"><Package className="h-5 w-5 text-brand/70" /></div>
                <div>
                  <button onClick={() => { setMode({ kind: "detail", id: r.id }); setTab("overview"); }} className="text-sm font-medium hover:text-brand">{r.name}</button>
                  <div className="text-[10px] text-muted-foreground">{str(r.extra.sku)} · {str(r.extra.type)} · {r.category}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span>{money(num(r.extra.price), str(r.extra.currency, "USD"))}</span>
                <Pill s={r.status} />
                <IconBtn onClick={() => { setMode({ kind: "edit", id: r.id }); setTab("overview"); }} title="Edit"><Pencil className="h-3.5 w-3.5" /></IconBtn>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {filtered.length > pageSize && (
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Page {page} of {totalPages} · {filtered.length} products</span>
          <div className="flex gap-1">
            <IconBtn disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} title="Prev"><ChevronLeft className="h-3.5 w-3.5" /></IconBtn>
            <IconBtn disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} title="Next"><ChevronRight className="h-3.5 w-3.5" /></IconBtn>
          </div>
        </div>
      )}
    </div>
  );
}

// ===================== Detail / Form =====================

function ProductDetail({
  role, record, editing, creating, onBack, onEdit, onCancel, onSave, onDuplicate, onDelete, onStatus, tab, onTab,
}: {
  role: RoleConfig;
  record: CrudRecord;
  editing: boolean;
  creating?: boolean;
  onBack: () => void;
  onEdit?: () => void;
  onCancel: () => void;
  onSave: (patch: Partial<CrudRecord>) => void;
  onDuplicate?: () => void;
  onDelete?: () => void;
  onStatus?: (s: RecordStatus) => void;
  tab: Tab;
  onTab: (t: Tab) => void;
}) {
  const [draft, setDraft] = useState<CrudRecord>(record);
  useEffect(() => setDraft(record), [record.id]);

  function setExtra(k: string, v: string | number) {
    setDraft((d) => ({ ...d, extra: { ...d.extra, [k]: v } }));
  }

  function save() {
    if (!draft.name.trim()) { toast.error("Name is required"); return; }
    if (num(draft.extra.price) < 0) { toast.error("Price must be ≥ 0"); return; }
    onSave({
      name: draft.name.trim(),
      status: draft.status,
      owner: draft.owner,
      category: draft.category,
      amount: num(draft.extra.price),
      notes: draft.notes,
      tags: draft.tags,
      extra: draft.extra,
    });
  }

  const tabs: { id: Tab; label: string; icon: typeof Package }[] = [
    { id: "overview",  label: "Overview",  icon: Layers },
    { id: "media",     label: "Media",     icon: ImageIcon },
    { id: "pricing",   label: "Pricing",   icon: DollarSign },
    { id: "inventory", label: "Inventory", icon: Box },
    { id: "seo",       label: "SEO",       icon: Globe },
    { id: "support",   label: "Support",   icon: ShieldCheck },
    { id: "versions",  label: "Versions",  icon: History },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "rules",     label: "Rules",     icon: Sparkles },
  ];

  return (
    <div className="space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <button onClick={onBack} className="inline-flex items-center gap-1 hover:text-foreground"><ArrowLeft className="h-3.5 w-3.5" /> Products</button>
        <span>/</span>
        <span className="text-foreground">{creating ? "New product" : record.name}</span>
      </div>

      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3 rounded-lg border border-border bg-surface p-4">
        <div className="flex items-start gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-md bg-gradient-to-br from-brand/30 to-surface-2">
            <Package className="h-6 w-6 text-brand" />
          </div>
          <div>
            {editing ? (
              <input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                className="w-full rounded border border-border bg-surface-2 px-2 py-1 text-base font-semibold outline-none focus:border-brand"
                placeholder="Product name" />
            ) : (
              <h2 className="text-base font-semibold">{record.name}</h2>
            )}
            <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
              <span className="font-mono">{str(record.extra.sku, "—")}</span>
              <span>·</span><span>{str(record.extra.type, "—")}</span>
              <span>·</span><span>v{str(record.extra.version, "1.0.0")}</span>
              <span>·</span><Pill s={draft.status} />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {editing ? (
            <>
              <button onClick={onCancel} className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs hover:bg-surface-2">Cancel</button>
              <button onClick={save} className="rounded-md bg-brand px-3 py-1.5 text-xs font-medium text-brand-foreground hover:bg-brand/90">{creating ? "Create" : "Save"}</button>
            </>
          ) : (
            <>
              {onStatus && (
                <select value={record.status} onChange={(e) => onStatus(e.target.value as RecordStatus)} className="rounded-md border border-border bg-surface-2 px-2 py-1.5 text-xs">
                  {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              )}
              <button onClick={onEdit} className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs hover:bg-surface-2 inline-flex items-center gap-1.5"><Pencil className="h-3.5 w-3.5" /> Edit</button>
              <button onClick={onDuplicate} className="rounded-md border border-border bg-surface px-3 py-1.5 text-xs hover:bg-surface-2 inline-flex items-center gap-1.5"><Copy className="h-3.5 w-3.5" /> Duplicate</button>
              <button onClick={onDelete} className="rounded-md border border-danger/40 bg-danger/10 text-danger px-3 py-1.5 text-xs hover:bg-danger/20 inline-flex items-center gap-1.5"><Trash2 className="h-3.5 w-3.5" /> Delete</button>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 rounded-lg border border-border bg-surface p-1">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => onTab(t.id)}
            className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs ${tab === t.id ? "bg-surface-2 text-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            <t.icon className="h-3.5 w-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {/* Tab body */}
      <div className="rounded-lg border border-border bg-surface p-4">
        {tab === "overview" && (
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Category">
              {editing ? (
                <select value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value })} className="input">
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              ) : <Read>{record.category}</Read>}
            </Field>
            <Field label="Sub Category">
              {editing ? <input value={str(draft.extra.subCategory)} onChange={(e) => setExtra("subCategory", e.target.value)} className="input" />
                : <Read>{str(record.extra.subCategory, "—")}</Read>}
            </Field>
            <Field label="Brand">
              {editing ? <input value={str(draft.extra.brand)} onChange={(e) => setExtra("brand", e.target.value)} className="input" />
                : <Read>{str(record.extra.brand, "—")}</Read>}
            </Field>
            <Field label="Type">
              {editing ? (
                <select value={str(draft.extra.type)} onChange={(e) => setExtra("type", e.target.value)} className="input">
                  {PRODUCT_TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
              ) : <Read>{str(record.extra.type, "—")}</Read>}
            </Field>
            <Field label="SKU">
              {editing ? <input value={str(draft.extra.sku)} onChange={(e) => setExtra("sku", e.target.value)} className="input" />
                : <Read className="font-mono">{str(record.extra.sku, "—")}</Read>}
            </Field>
            <Field label="Product Code">
              {editing ? <input value={str(draft.extra.code)} onChange={(e) => setExtra("code", e.target.value)} className="input" />
                : <Read className="font-mono">{str(record.extra.code, "—")}</Read>}
            </Field>
            <Field label="Barcode">
              {editing ? <input value={str(draft.extra.barcode)} onChange={(e) => setExtra("barcode", e.target.value)} className="input" />
                : <Read className="font-mono">{str(record.extra.barcode, "—")}</Read>}
            </Field>
            <Field label="Visibility">
              {editing ? (
                <select value={str(draft.extra.visibility, "public")} onChange={(e) => setExtra("visibility", e.target.value)} className="input">
                  {VISIBILITIES.map((v) => <option key={v}>{v}</option>)}
                </select>
              ) : <Read>{str(record.extra.visibility, "public")}</Read>}
            </Field>
            <Field label="Tags" full>
              {editing ? (
                <input value={draft.tags.join(", ")} onChange={(e) => setDraft({ ...draft, tags: e.target.value.split(",").map((t) => t.trim()).filter(Boolean) })}
                  className="input" placeholder="comma, separated, tags" />
              ) : (
                <div className="flex flex-wrap gap-1">
                  {record.tags.length ? record.tags.map((t) => <span key={t} className="rounded-full bg-surface-2 px-2 py-0.5 text-[10px]">{t}</span>) : <Read>—</Read>}
                </div>
              )}
            </Field>
            <Field label="Notes / Description" full>
              {editing ? (
                <textarea value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })} rows={4} className="input" />
              ) : (
                <p className="whitespace-pre-wrap text-xs text-muted-foreground">{record.notes || "—"}</p>
              )}
            </Field>
            <div className="md:col-span-2 grid grid-cols-3 gap-2">
              <FlagToggle label="Featured" value={num(draft.extra.featured) === 1} editing={editing} onChange={(v) => setExtra("featured", v ? 1 : 0)} />
              <FlagToggle label="Trending" value={num(draft.extra.trending) === 1} editing={editing} onChange={(v) => setExtra("trending", v ? 1 : 0)} />
              <FlagToggle label="Bestseller" value={num(draft.extra.bestseller) === 1} editing={editing} onChange={(v) => setExtra("bestseller", v ? 1 : 0)} />
              <FlagToggle label="AI Ready" value={num(draft.extra.aiReady) === 1} editing={editing} onChange={(v) => setExtra("aiReady", v ? 1 : 0)} />
            </div>
          </div>
        )}

        {tab === "media" && (
          <div className="grid gap-3 md:grid-cols-2">
            <MediaCard icon={ImageIcon} title="Cover & Gallery" desc="Drop images or paste a URL. Stored per-product." />
            <MediaCard icon={Video} title="Demo Videos" desc="Showcase the product with up to 5 demo videos." />
            <MediaCard icon={FileText} title="Documentation" desc="Upload PDFs, manuals, install guides." />
            <Field label="Demo URL" full>
              {editing ? <input value={str(draft.extra.demoUrl)} onChange={(e) => setExtra("demoUrl", e.target.value)} className="input" placeholder="https://" />
                : <Read>{str(record.extra.demoUrl, "—")}</Read>}
            </Field>
            <Field label="Download URL" full>
              {editing ? <input value={str(draft.extra.downloadUrl)} onChange={(e) => setExtra("downloadUrl", e.target.value)} className="input" placeholder="https://" />
                : <Read>{str(record.extra.downloadUrl, "—")}</Read>}
            </Field>
          </div>
        )}

        {tab === "pricing" && (
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Currency">
              {editing ? (
                <select value={str(draft.extra.currency, "USD")} onChange={(e) => setExtra("currency", e.target.value)} className="input">
                  {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              ) : <Read>{str(record.extra.currency, "USD")}</Read>}
            </Field>
            <Field label="MRP">
              {editing ? <input type="number" value={num(draft.extra.mrp)} onChange={(e) => setExtra("mrp", Number(e.target.value))} className="input" />
                : <Read>{money(num(record.extra.mrp), str(record.extra.currency, "USD"))}</Read>}
            </Field>
            <Field label="Sale Price">
              {editing ? <input type="number" value={num(draft.extra.price)} onChange={(e) => setExtra("price", Number(e.target.value))} className="input" />
                : <Read>{money(num(record.extra.price), str(record.extra.currency, "USD"))}</Read>}
            </Field>
            <Field label="Discount %">
              {editing ? <input type="number" value={num(draft.extra.discountPct)} onChange={(e) => setExtra("discountPct", Number(e.target.value))} className="input" />
                : <Read>{num(record.extra.discountPct)}%</Read>}
            </Field>
            <Field label="Lifetime Price">
              {editing ? <input type="number" value={num(draft.extra.lifetimePrice)} onChange={(e) => setExtra("lifetimePrice", Number(e.target.value))} className="input" />
                : <Read>{money(num(record.extra.lifetimePrice), str(record.extra.currency, "USD"))}</Read>}
            </Field>
            <Field label="Tax %">
              {editing ? <input type="number" value={num(draft.extra.taxPct)} onChange={(e) => setExtra("taxPct", Number(e.target.value))} className="input" />
                : <Read>{num(record.extra.taxPct)}%</Read>}
            </Field>
            <div className="md:col-span-3 rounded-md border border-border bg-surface-2 p-3 text-xs">
              <div className="mb-1 font-medium">Effective price preview</div>
              <div className="text-muted-foreground">
                {money(num(draft.extra.price), str(draft.extra.currency, "USD"))} +
                {" "}{num(draft.extra.taxPct)}% tax =
                <span className="ml-1 font-semibold text-foreground">
                  {money(num(draft.extra.price) * (1 + num(draft.extra.taxPct) / 100), str(draft.extra.currency, "USD"))}
                </span>
              </div>
            </div>
          </div>
        )}

        {tab === "inventory" && (
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Stock">
              {editing ? <input type="number" value={num(draft.extra.stock)} onChange={(e) => setExtra("stock", Number(e.target.value))} className="input" />
                : <Read>{num(record.extra.stock)}</Read>}
            </Field>
            <Field label="Low-stock threshold">
              {editing ? <input type="number" value={num(draft.extra.lowStock)} onChange={(e) => setExtra("lowStock", Number(e.target.value))} className="input" />
                : <Read>{num(record.extra.lowStock)}</Read>}
            </Field>
            <Field label="Compatibility">
              {editing ? <input value={str(draft.extra.compatibility)} onChange={(e) => setExtra("compatibility", e.target.value)} className="input" />
                : <Read>{str(record.extra.compatibility, "—")}</Read>}
            </Field>
            <Field label="Dependencies" full>
              {editing ? <input value={str(draft.extra.dependencies)} onChange={(e) => setExtra("dependencies", e.target.value)} className="input" />
                : <Read>{str(record.extra.dependencies, "—")}</Read>}
            </Field>
            {num(record.extra.stock) <= num(record.extra.lowStock) && (
              <div className="md:col-span-3 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs text-warning">
                Low stock warning — only {num(record.extra.stock)} units left.
              </div>
            )}
          </div>
        )}

        {tab === "seo" && (
          <div className="grid gap-3">
            <Field label="SEO Title" full>
              {editing ? <input value={str(draft.extra.seoTitle)} onChange={(e) => setExtra("seoTitle", e.target.value)} className="input" />
                : <Read>{str(record.extra.seoTitle, "—")}</Read>}
            </Field>
            <Field label="Meta Description" full>
              {editing ? <textarea rows={3} value={str(draft.extra.seoDesc)} onChange={(e) => setExtra("seoDesc", e.target.value)} className="input" />
                : <Read>{str(record.extra.seoDesc, "—")}</Read>}
            </Field>
            <Field label="Keywords" full>
              {editing ? <input value={str(draft.extra.seoKeywords)} onChange={(e) => setExtra("seoKeywords", e.target.value)} className="input" placeholder="comma, separated" />
                : <Read>{str(record.extra.seoKeywords, "—")}</Read>}
            </Field>
            <Field label="FAQs" full>
              {editing ? <textarea rows={4} value={str(draft.extra.faqs)} onChange={(e) => setExtra("faqs", e.target.value)} className="input" placeholder="Q: ... A: ..." />
                : <Read>{str(record.extra.faqs, "—")}</Read>}
            </Field>
          </div>
        )}

        {tab === "support" && (
          <div className="grid gap-3 md:grid-cols-2">
            <MediaCard icon={FileText} title="Release Notes" desc={str(record.extra.releaseNotes, "—")} />
            <MediaCard icon={LinkIcon} title="Support Files" desc="Upload installers, license keys and config templates." />
            <Field label="Release Notes" full>
              {editing ? <textarea rows={4} value={str(draft.extra.releaseNotes)} onChange={(e) => setExtra("releaseNotes", e.target.value)} className="input" />
                : <Read>{str(record.extra.releaseNotes, "—")}</Read>}
            </Field>
          </div>
        )}

        {tab === "versions" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Field label="Current version">
                {editing ? <input value={str(draft.extra.version, "1.0.0")} onChange={(e) => setExtra("version", e.target.value)} className="input" />
                  : <Read>{str(record.extra.version, "1.0.0")}</Read>}
              </Field>
            </div>
            <div>
              <div className="mb-2 text-xs font-medium">Update History</div>
              <ol className="relative ml-3 space-y-2 border-l border-border pl-4 text-xs">
                {record.audit.slice(0, 10).map((a) => (
                  <li key={a.id}>
                    <span className="absolute -left-1.5 mt-1 h-3 w-3 rounded-full bg-brand" />
                    <div className="font-medium">{a.action}</div>
                    <div className="text-muted-foreground">{fmtDate(a.date)} · {a.by}{a.detail ? ` · ${a.detail}` : ""}</div>
                  </li>
                ))}
                {record.audit.length === 0 && <li className="text-muted-foreground">No history yet.</li>}
              </ol>
            </div>
          </div>
        )}

        {tab === "analytics" && (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Kpi icon={Eye} label="Views" value={num(record.extra.views).toLocaleString()} />
            <Kpi icon={DollarSign} label="Sales" value={num(record.extra.sales).toLocaleString()} />
            <Kpi icon={Star} label="Rating" value={`${num(record.extra.rating).toFixed(1)} ★`} />
            <Kpi icon={Tag} label="Reviews" value={num(record.extra.reviews).toLocaleString()} />
            <div className="col-span-2 rounded-md border border-border bg-surface-2 p-3 text-xs md:col-span-4">
              <div className="mb-1 font-medium">Lifetime revenue</div>
              <div className="text-2xl font-semibold">
                {money(num(record.extra.price) * num(record.extra.sales), str(record.extra.currency, "USD"))}
              </div>
            </div>
          </div>
        )}

        {tab === "rules" && (
          <div className="grid gap-3 md:grid-cols-2">
            <FlagToggle label="Allow resellers" value={num(draft.extra.allowResell) === 1} editing={editing} onChange={(v) => setExtra("allowResell", v ? 1 : 0)} />
            <FlagToggle label="Allow affiliates" value={num(draft.extra.allowAffiliate) === 1} editing={editing} onChange={(v) => setExtra("allowAffiliate", v ? 1 : 0)} />
            <FlagToggle label="Requires approval" value={num(draft.extra.requiresApproval) === 1} editing={editing} onChange={(v) => setExtra("requiresApproval", v ? 1 : 0)} />
            <FlagToggle label="Geo restricted" value={num(draft.extra.geoRestricted) === 1} editing={editing} onChange={(v) => setExtra("geoRestricted", v ? 1 : 0)} />
          </div>
        )}
      </div>
    </div>
  );
}

// ===================== Bits =====================

function Kpi({ icon: I, label, value, tone }: { icon: typeof Package; label: string; value: string; tone?: "ok" | "warn" }) {
  const cls = tone === "warn" ? "text-warning" : "text-foreground";
  return (
    <div className="rounded-lg border border-border bg-surface p-3">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-wide text-muted-foreground">
        <I className="h-3.5 w-3.5" /> {label}
      </div>
      <div className={`mt-1 text-lg font-semibold ${cls}`}>{value}</div>
    </div>
  );
}

function IconBtn({ children, onClick, title, disabled }: { children: React.ReactNode; onClick?: () => void; title?: string; disabled?: boolean }) {
  return (
    <button onClick={onClick} title={title} disabled={disabled}
      className="rounded border border-border bg-surface p-1.5 text-muted-foreground hover:text-foreground hover:bg-surface-2 disabled:opacity-40">
      {children}
    </button>
  );
}

function Field({ label, full, children }: { label: string; full?: boolean; children: React.ReactNode }) {
  return (
    <div className={full ? "md:col-span-2" : ""}>
      <label className="mb-1 block text-[10px] uppercase tracking-wide text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}
function Read({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`text-sm ${className}`}>{children}</div>;
}
function FlagToggle({ label, value, onChange, editing }: { label: string; value: boolean; onChange: (v: boolean) => void; editing: boolean }) {
  return (
    <label className={`flex items-center justify-between gap-2 rounded-md border border-border bg-surface-2 px-3 py-2 text-xs ${editing ? "cursor-pointer" : ""}`}>
      <span>{label}</span>
      <input type="checkbox" disabled={!editing} checked={value} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}
function MediaCard({ icon: I, title, desc }: { icon: typeof Package; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3 rounded-md border border-dashed border-border bg-surface-2 p-3">
      <div className="rounded bg-surface p-2"><I className="h-4 w-4 text-brand" /></div>
      <div>
        <div className="text-xs font-medium">{title}</div>
        <p className="text-[11px] text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

function emptyProduct(): CrudRecord {
  return {
    id: "new", name: "", status: "draft", owner: "you", category: CATEGORIES[0],
    amount: 0, date: new Date().toISOString(), notes: "", tags: [],
    comments: [], audit: [], attachments: [],
    extra: {
      sku: "", code: "", barcode: "", type: "SaaS", visibility: "public",
      currency: "USD", price: 0, mrp: 0, discountPct: 0, lifetimePrice: 0, taxPct: 18,
      stock: 0, lowStock: 5, brand: "", subCategory: "",
      featured: 0, trending: 0, bestseller: 0, aiReady: 0,
      version: "1.0.0", rating: 0, reviews: 0, views: 0, sales: 0,
      demoUrl: "", downloadUrl: "",
      seoTitle: "", seoDesc: "", seoKeywords: "",
      releaseNotes: "", compatibility: "", dependencies: "", faqs: "",
    },
  };
}
