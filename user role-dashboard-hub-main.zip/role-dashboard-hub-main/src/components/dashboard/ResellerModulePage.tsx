import type { RoleConfig } from "@/lib/roles";
import { CrudWorkspace } from "@/components/dashboard/CrudWorkspace";
import { ProductWorkspace } from "@/components/dashboard/ProductWorkspace";

export function ResellerModulePage({ role, moduleKey, onBack }: { role: RoleConfig; moduleKey: string; onBack: () => void }) {
  if (moduleKey === "products" || moduleKey === "catalog") {
    return <ProductWorkspace role={role} moduleKey={moduleKey} onBack={onBack} />;
  }
  return <CrudWorkspace role={role} moduleKey={moduleKey} onBack={onBack} />;
}
