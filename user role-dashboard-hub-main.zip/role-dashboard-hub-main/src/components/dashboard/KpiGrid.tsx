import { ArrowDownRight, ArrowUpRight, MoreVertical } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Kpi } from "@/lib/roles";

const toneStyle: Record<Kpi["tone"], { bg: string; fg: string; ring: string; stroke: string; glow: string }> = {
  brand:   { bg: "bg-brand/15",                                   fg: "text-[oklch(0.78_0.2_265)]",  ring: "hover:border-[oklch(0.62_0.22_265)]/60", stroke: "oklch(0.72 0.2 265)",  glow: "oklch(0.62 0.22 265 / 0.35)" },
  success: { bg: "bg-success/15",                                  fg: "text-success",                ring: "hover:border-success/60",                stroke: "oklch(0.78 0.16 155)", glow: "oklch(0.72 0.16 155 / 0.35)" },
  warning: { bg: "bg-warning/15",                                  fg: "text-warning",                ring: "hover:border-warning/60",                stroke: "oklch(0.82 0.16 75)",  glow: "oklch(0.78 0.16 75 / 0.35)"  },
  danger:  { bg: "bg-destructive/15",                              fg: "text-destructive",            ring: "hover:border-destructive/60",            stroke: "oklch(0.7 0.22 25)",   glow: "oklch(0.62 0.24 25 / 0.35)"  },
  violet:  { bg: "bg-[oklch(0.65_0.22_320)]/15",                   fg: "text-[oklch(0.82_0.18_320)]", ring: "hover:border-[oklch(0.65_0.22_320)]/60", stroke: "oklch(0.78 0.2 320)",  glow: "oklch(0.65 0.22 320 / 0.35)" },
  cyan:    { bg: "bg-[oklch(0.7_0.16_210)]/15",                    fg: "text-[oklch(0.82_0.15_210)]", ring: "hover:border-[oklch(0.7_0.16_210)]/60",  stroke: "oklch(0.78 0.15 210)", glow: "oklch(0.7 0.16 210 / 0.35)"  },
};

// Deterministic pseudo-random so values are stable per KPI but feel alive
function seeded(key: string) {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return () => {
    h = (h * 1664525 + 1013904223) >>> 0;
    return (h % 1000) / 1000;
  };
}

function makeSeries(key: string, n = 16) {
  const rand = seeded(key);
  const arr: number[] = [];
  let v = 30 + rand() * 40;
  for (let i = 0; i < n; i++) {
    v += (rand() - 0.45) * 14;
    v = Math.max(8, Math.min(95, v));
    arr.push(v);
  }
  return arr;
}

function formatValue(n: number, unit?: string) {
  if (unit === "$") {
    if (n >= 1000) return "$" + (n / 1000).toFixed(1) + "k";
    return "$" + Math.round(n);
  }
  if (unit === "%") return n.toFixed(1);
  if (n >= 1000) return (n / 1000).toFixed(1) + "k";
  return Math.round(n).toString();
}

function useCountUp(target: number, duration = 900) {
  const [v, setV] = useState(0);
  const raf = useRef<number | null>(null);
  useEffect(() => {
    const start = performance.now();
    const from = 0;
    function tick(t: number) {
      const p = Math.min(1, (t - start) / duration);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - p, 3);
      setV(from + (target - from) * eased);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    }
    raf.current = requestAnimationFrame(tick);
    return () => { if (raf.current) cancelAnimationFrame(raf.current); };
  }, [target, duration]);
  return v;
}

function Sparkline({ data, stroke }: { data: number[]; stroke: string }) {
  const w = 88, h = 26;
  const min = Math.min(...data), max = Math.max(...data);
  const span = Math.max(1, max - min);
  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((d - min) / span) * h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  const area = `0,${h} ${pts} ${w},${h}`;
  const gradId = `sg-${stroke.replace(/[^a-z0-9]/gi, "")}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h} className="overflow-visible">
      <defs>
        <linearGradient id={gradId} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.35" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={area} fill={`url(#${gradId})`} />
      <polyline
        className="sv-spark-path"
        points={pts}
        fill="none"
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function KpiCard({ k, onOpen }: { k: Kpi; onOpen: (k: string) => void }) {
  const t = toneStyle[k.tone];
  const series = makeSeries(k.key);
  const last = series[series.length - 1];
  const prev = series[series.length - 2];
  const trend = ((last - prev) / Math.max(1, prev)) * 100;
  const up = trend >= 0;
  const target = k.unit === "$" ? Math.round(last * 80) : k.unit === "%" ? last : Math.round(last * 12);
  const value = useCountUp(target);
  const progress = Math.min(100, Math.max(4, last));

  return (
    <button
      onClick={() => onOpen(k.key)}
      className={`group sv-lift relative text-left rounded-2xl bg-card border border-border p-4 shadow-card overflow-hidden ${t.ring}`}
      style={{ ['--kpi-glow' as any]: t.glow }}
    >
      {/* ambient glow */}
      <span
        aria-hidden
        className="pointer-events-none absolute -top-10 -right-10 h-28 w-28 rounded-full opacity-60 blur-2xl transition-opacity duration-300 group-hover:opacity-100"
        style={{ background: t.glow }}
      />

      <div className="relative flex items-start justify-between">
        <div className={`grid h-9 w-9 place-items-center rounded-xl ${t.bg} ring-1 ring-inset ring-white/5`}>
          <k.icon className={`h-4 w-4 ${t.fg}`} />
        </div>
        <span className="opacity-0 group-hover:opacity-100 transition text-muted-foreground">
          <MoreVertical className="h-3.5 w-3.5" />
        </span>
      </div>

      <div className="relative mt-4 flex items-end justify-between gap-2">
        <div className="flex items-baseline gap-1 sv-count">
          <span className="text-2xl font-black tracking-tight text-foreground tabular-nums">
            {formatValue(value, k.unit)}
          </span>
          {k.unit === "%" && <span className="text-sm font-bold text-foreground/60">%</span>}
        </div>
        <div className="opacity-90">
          <Sparkline data={series} stroke={t.stroke} />
        </div>
      </div>

      <div className="relative mt-2 flex items-center justify-between">
        <div className="text-xs text-muted-foreground truncate">{k.label}</div>
        <span
          className={`inline-flex items-center gap-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${
            up ? "text-success bg-success/10" : "text-destructive bg-destructive/10"
          }`}
        >
          {up ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
          {Math.abs(trend).toFixed(1)}%
        </span>
      </div>

      {/* progress */}
      <div className="relative mt-3 h-1 rounded-full bg-white/5 overflow-hidden">
        <div
          className="h-full rounded-full transition-[width] duration-700"
          style={{
            width: `${progress}%`,
            background: `linear-gradient(90deg, ${t.stroke}, ${t.stroke})`,
            boxShadow: `0 0 10px ${t.glow}`,
          }}
        />
      </div>
    </button>
  );
}

export function KpiGrid({ items, onOpen }: { items: Kpi[]; onOpen: (k: string) => void }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 md:gap-4">
      {items.map((k) => <KpiCard key={k.key} k={k} onOpen={onOpen} />)}
    </div>
  );
}
