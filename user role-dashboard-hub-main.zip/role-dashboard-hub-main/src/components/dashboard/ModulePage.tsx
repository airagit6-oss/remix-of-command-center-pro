import type { RoleConfig } from "@/lib/roles";
import { CrudWorkspace } from "@/components/dashboard/CrudWorkspace";
import { ProductWorkspace } from "@/components/dashboard/ProductWorkspace";

const PRODUCT_MODULE_KEYS = new Set([
  "products", "product", "catalog", "active-products", "my-products",
]);

export function ModulePage({ role, moduleKey, onBack }: { role: RoleConfig; moduleKey: string; onBack: () => void }) {
  if (PRODUCT_MODULE_KEYS.has(moduleKey)) {
    return <ProductWorkspace role={role} moduleKey={moduleKey} onBack={onBack} />;
  }
  return <CrudWorkspace role={role} moduleKey={moduleKey} onBack={onBack} />;
}
